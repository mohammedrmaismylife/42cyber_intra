# Fix — Mitigating Server-Side Template Injection (SSTI)

The root cause of this vulnerability is that user-controlled input
was embedded directly into the template source and evaluated as
template *code*, instead of being passed safely as a *value* into an
already-defined, trusted template. The fixes below address that gap
from several angles — defense in depth is recommended, combining more
than one of these together.

## 1. Never render user input as a template (primary fix)

The single most important fix: **never pass raw user input into a
template-rendering function** (e.g. Jinja2's `render_template_string()`
or an f-string/`.format()`-built template). User input should only
ever be passed in as a **variable/value** to a template that is
already fully defined by the developer, never as part of the template
source itself.

```python
# VULNERABLE — user input becomes part of the template source
return render_template_string(f"Hello, {{ '{user_input}' }}!")

# SAFE — user input is only ever a variable, never template code
return render_template_string("Hello, {{ name }}!", name=user_input)
```

In the safe version, Jinja2 treats `user_input` purely as a string to
display — even if it contains `{{7*7}}`, it will be shown literally
as text, not evaluated.

## 2. Use a sandboxed template environment

If a use case genuinely requires rendering user-supplied templates
(e.g. letting users customize email templates), use the engine's
sandboxed execution mode, which restricts access to unsafe attributes
and built-ins.

```python
from jinja2.sandbox import SandboxedEnvironment

env = SandboxedEnvironment()
template = env.from_string(user_supplied_template)
output = template.render(name=username)
```

Jinja2's `SandboxedEnvironment` blocks access to dunder attributes
(like `__class__`, `__globals__`, `__subclasses__`) by default,
closing off the exact object-traversal technique used in this
exercise. Note that sandboxing reduces risk but is not a silver
bullet — sandbox escapes have historically been found, so it should
be paired with the other mitigations below.

## 3. Prefer logic-less template engines for untrusted input

For any feature where end users supply the template content itself,
consider a logic-less templating language (e.g. Mustache) that has no
support for expressions, attribute access, or method calls at all —
removing the attack surface entirely rather than trying to sandbox it.

## 4. Validate and restrict input

Where free-form user text must be reflected in output, apply strict
input validation/allow-listing (e.g. reject `{{`, `{%`, `${`, and
similar template delimiter sequences) as an additional defensive
layer — not a replacement for fix #1, but useful in case a rendering
call is accidentally misused elsewhere in the codebase.

## 5. Run with least privilege

Run the web application process with the minimum OS-level permissions
necessary. Even if an attacker achieves code execution through SSTI,
limiting the process's file-system and network access reduces the
blast radius (e.g. prevents it from reading sensitive files like
`/etc/shadow`, SSH keys, or reaching internal network services).

## Summary

| Defense | Protects against |
|---|---|
| Never render raw user input as a template | The vulnerability class itself |
| Sandboxed environment | Access to dangerous Python internals even if templates are user-defined |
| Logic-less template engine | Expression/attribute-access attack surface entirely |
| Input validation | Accidental exposure via a misused render call |
| Least privilege | Impact/blast radius of a successful exploit |

The most important takeaway: **template rendering functions should
treat user data as data, never as code.** This single discipline
(fix #1) would have prevented the exploit demonstrated in
`Payloads.md` entirely.
