# Vulnerability: Server-Side Template Injection (SSTI)

## Type

**SSTI — Server-Side Template Injection**, listed under the OWASP
category of Injection flaws (historically OWASP Top 10 A1/A03:2021 —
Injection).

## What is SSTI?

Web frameworks commonly use **template engines** (e.g. Jinja2 for
Python/Flask, Twig for PHP, FreeMarker for Java) to dynamically build
HTML pages by substituting placeholders — such as `{{ variable }}` —
with data before rendering.

SSTI happens when **user-controlled input is concatenated directly
into the template source itself**, instead of being passed safely as
a *value* to an existing template. When this happens, the template
engine doesn't just display the user's text — it **parses and
executes** it as template code. Since most template engines (Jinja2
included) are Turing-complete and allow attribute/method traversal on
Python objects, an attacker who can inject template syntax can often
walk through Python's object model to reach dangerous built-ins (like
`os` or `subprocess`), ultimately achieving **arbitrary code
execution (RCE)** on the server.

## Where the vulnerability lives in this application

The application's "Enter your input" field is rendered back to the
user as part of a Jinja2 template, without sanitizing or escaping
template syntax. This was visible immediately: the raw `{{ result }}`
placeholder appeared unrendered on the initial page, a strong hint
that user input flows directly into template construction.

### Step 1 — Confirming the engine

Submitting a simple arithmetic payload:

```
{{5*5}}
```

returned `25` instead of the literal string `5*5`, confirming the
input is being evaluated as Jinja2 template code rather than treated
as plain text.

### Step 2 — Escalating to code execution

Submitting:

```
{{ cycler.__init__.__globals__.os.popen('cat /etc/passwd').read() }}
```

successfully returned the **full contents of `/etc/passwd`** rendered
directly on the page.

This works because:
- `cycler` is a built-in Jinja2 global, always available inside the
  template context, independent of what the application itself
  defines.
- `cycler.__init__.__globals__` reaches into the Python module
  (`jinja2/utils.py`) that defines `cycler`, exposing that module's
  global namespace — which includes `os`, imported by the module
  itself.
- From there, `os.popen('cat /etc/passwd').read()` executes an
  arbitrary shell command and returns its output straight into the
  rendered page.

## Why this matters

SSTI is critical because it does not stop at reading one file: once
`os` (or any similarly dangerous module) is reachable, an attacker
effectively has **full remote code execution** on the server — they
can read any file, exfiltrate secrets/credentials, modify data,
pivot to other systems, or run arbitrary commands with the privileges
of the web application process.

## Exploitation scenarios

1. **Customizable email/notification templates.** Many applications
   let users (or admins) customize the wording of automated emails
   (e.g. "Welcome {{username}}!") by saving a template string that is
   later rendered with user/account data. If the raw user-submitted
   template text is passed to the engine's render function instead of
   being treated as a fixed template with safe variable substitution,
   an attacker can inject SSTI payloads directly into the saved
   template and achieve RCE the next time it's rendered (e.g. when an
   email is sent).

2. **Reporting / document generation tools.** Applications that
   generate PDFs, invoices, or reports from user-supplied formatting
   strings or custom fields (e.g. "report title", "custom footer
   text") are a common real-world source of SSTI, since that text is
   frequently fed straight into a template engine to produce the
   final document, without the developers realizing the field is
   being evaluated rather than just displayed.

3. **CMS/page-builder "preview" features.** Content management
   systems that let users preview custom page layouts or widgets
   before publishing often render the user's raw markup through the
   same template engine used for the live site, without isolating or
   sandboxing that preview render step — exposing the same RCE path
   demonstrated in this exercise.

## Sources

- OWASP on Injection flaws:
  https://owasp.org/www-community/Injection_Flaws
- PortSwigger — Server-Side Template Injection:
  https://portswigger.net/web-security/server-side-template-injection
