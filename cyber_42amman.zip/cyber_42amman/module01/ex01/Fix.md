# Fix — Mitigating XXE (XML External Entity Injection)

The root cause of this vulnerability is that the XML parser used by
the application resolves `DOCTYPE` declarations and `SYSTEM`/`PUBLIC`
external entities by default, without the application explicitly
disabling that behavior. The fixes below address this at the
parser-configuration level, which is the correct and most reliable
place to fix XXE — not at the input-validation level.

## 1. Disable DTD processing entirely (primary fix)

The most effective fix is to **completely disable DTD processing** at
the parser level, since almost no legitimate use case for
user-submitted XML requires custom DTDs or entity definitions.

**Example (Python, `lxml`):**
```python
from lxml import etree

parser = etree.XMLParser(resolve_entities=False, no_network=True, dtd_validation=False)
tree = etree.parse(xml_input, parser)
```

**Example (Python, `defusedxml` — purpose-built safe replacement):**
```python
from defusedxml.ElementTree import parse

tree = parse(xml_input)  # raises on any DTD/entity by default
```

**Example (Java, `DocumentBuilderFactory`):**
```java
DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
dbf.setXIncludeAware(false);
dbf.setExpandEntityReferences(false);
```
