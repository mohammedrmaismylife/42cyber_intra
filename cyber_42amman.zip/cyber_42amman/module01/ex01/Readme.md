# Vulnerability: XXE (XML External Entity Injection)

## Type

**XXE — XML External Entity Injection**, listed under the OWASP Top
10 (historically A4:2017, now folded into **A05:2021 — Security
Misconfiguration**).

## What is XXE?

XXE is a vulnerability that occurs when an application parses
**user-supplied XML input** using an XML parser that has **external
entity processing enabled**. The XML specification allows a document
to define a **DTD (Document Type Definition)**, which can declare
custom **ENTITY** values — essentially reusable shortcuts that the
parser substitutes wherever they're referenced in the document.

Critically, an entity can be declared as `SYSTEM`, pointing to an
external resource — including a **local file on the server's
filesystem** via the `file://` URI scheme, or even a remote URL. If
the parser resolves `SYSTEM` entities (which many XML parsers do by
default unless explicitly configured otherwise), an attacker can
define an entity pointing to a sensitive local file, reference that
entity inside the XML body, and have its contents reflected back in
the application's output — effectively turning an XML "parse" feature
into an arbitrary local file read primitive.

## Where the vulnerability lives in this application

The application exposes a "Parse XML" feature: a textarea where the
user submits raw XML, which the server parses and reflects the result
back on the page. The parser used by the backend processes DTDs and
resolves `SYSTEM` external entities without restriction, and performs
no input validation or sanitization on the submitted XML before
parsing it.

### Confirming and exploiting the vulnerability

Submitting the following XML through the "Enter xml to parse" field
and clicking "Parse":

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE foo [
  <!ENTITY xxe SYSTEM "file:///etc/passwd">
]>
<foo>&xxe;</foo>
```

returned the **full contents of `/etc/passwd`** rendered inside the
`<foo>` element in the parser's output.

**Why this works:**
- The `<!DOCTYPE foo [...]>` block defines an internal DTD for the
  document.
- `<!ENTITY xxe SYSTEM "file:///etc/passwd">` declares a custom
  external entity named `xxe`, pointing to a local file via the
  `file://` scheme.
- Every occurrence of `&xxe;` in the document is replaced by the
  parser with the resolved content of that file **before** the
  application logic even sees the parsed structure.
- Since `&xxe;` is placed as the content of the root element `<foo>`,
  the parser's output for that element becomes the entire contents of
  `/etc/passwd`.

## Why this matters

XXE is dangerous because it gives an attacker a direct, server-side
local file read primitive — often without any authentication beyond
whatever access the vulnerable form already has. Beyond reading
arbitrary files (configuration files, credentials, SSH keys, source
code), XXE can frequently be escalated further into:

- **Server-Side Request Forgery (SSRF)**, by pointing the entity at
  an internal URL instead of a local file.
- **Denial of Service**, via entity expansion attacks (the "billion
  laughs" pattern), by nesting entities that reference each other
  recursively.
- In some parser/environment combinations, **remote code execution**,
  depending on what protocols and wrappers the parser supports.

## Sources

- OWASP XXE Prevention Cheat Sheet:
  https://cheatsheetseries.owasp.org/cheatsheets/XML_External_Entity_Prevention_Cheat_Sheet.html
- OWASP — XML External Entity (XXE) Processing:
  https://owasp.org/www-community/vulnerabilities/XML_External_Entity_(XXE)_Processing

## Exploitation scenarios

1. **File upload / document processing features.** Many real-world
   applications accept file formats that are internally just XML —
   SVG images, DOCX/XLSX/PPTX (Office Open XML), or SOAP API payloads.
   A "profile picture upload" that accepts SVG, or an "import data
   from XML/Excel" feature, can expose the exact same XXE primitive
   demonstrated here if the parser isn't hardened, even though the
   feature has nothing to do with "parsing raw XML" on its surface.

2. **B2B / SOAP-based integrations.** Legacy enterprise systems that
   communicate via SOAP web services exchange XML payloads directly
   between servers. If the receiving server's SOAP parser isn't
   configured to disable external entities, any party able to send a
   request (a partner integration, or an attacker who compromises one
   endpoint) can read local files or pivot to internal network
   requests (SSRF) on the receiving server.
