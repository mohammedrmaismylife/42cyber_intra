# Vulnerability: SSRF leading to LFI

## Type
Server-Side Request Forgery (SSRF) — OWASP Top 10 (A10:2021)
Chained with Local File Inclusion (LFI) via unsafe URL scheme handling.

## Explanation
The application exposes a form field that takes a URL from the user and fetches
its content server-side (e.g. via curl, file_get_contents, or requests). Because
the application does not validate or restrict the allowed URL schemes/hosts,
an attacker can supply schemes other than http/https, such as `file://`, which
makes the server read local files from its own filesystem instead of performing
a network request. This allows reading sensitive files like /etc/passwd,
configuration files, SSH keys, etc.

## Root cause
- No allow-list of permitted schemes (only http/https should be allowed)
- No allow-list of permitted hosts/IP ranges (internal IPs, localhost, 169.254.169.254 should be blocked)
- User input passed directly to the fetch function without validation
