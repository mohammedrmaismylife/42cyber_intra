# Payloads

1. `file:///etc/passwd` — reads the system password file, confirms LFI via SSRF.



## Exploitation scenarios
1. **Internal network reconnaissance / pivoting**: attacker uses the SSRF to scan and
   reach internal-only services (databases, admin panels, internal APIs) that are not
   exposed to the internet, using the vulnerable server as a proxy.
2. **Credential theft via cloud metadata**: if the app runs on AWS/GCP/Azure, the
   attacker points the URL field to the instance metadata service to steal IAM
   credentials or access tokens, potentially compromising the whole cloud account.
3. **Local file disclosure (LFI)**: as demonstrated above, using `file://` to read
   `/etc/passwd`, app source code, config files with secrets, or SSH keys.
