# Fix / Mitigation

1. **Restrict allowed URL schemes**: only allow `http://` and `https://`.
   Explicitly reject `file://`, `gopher://`, `ftp://`, `dict://`, `php://`, etc.

2. **Allow-list hosts/domains** instead of blocking (deny-lists are easy to bypass
   with redirects, DNS rebinding, IP encoding tricks, etc.). Only permit requests
   to known, trusted external hosts if the feature requires it.

3. **Block requests to internal/private IP ranges**:
   - 127.0.0.0/8, 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, 169.254.0.0/16, ::1
   Resolve the hostname first and validate the resulting IP before connecting
   (to prevent DNS rebinding bypassing a naive string check).

4. **Disable automatic redirect following**, or re-validate the destination of
   each redirect, since an attacker can bypass checks with a 302 redirect to
   an internal address.

5. **Run the fetching component with least privilege** and in a network-segmented
   environment (e.g. no access to internal services or metadata endpoints) as
   defense in depth.

6. **Use a dedicated, well-tested SSRF-protection library** instead of writing
   custom validation.

## Sources
- OWASP SSRF Prevention Cheat Sheet
- OWASP Top 10 2021 – A10: Server-Side Request Forgery
