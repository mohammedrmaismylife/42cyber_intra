# Payloads and Test Results

## Test 1: Read `/etc/passwd`

**Objective:** Display the contents of `/etc/passwd`.

**Input:** Base64-encoded serialized data representing the command `cat /etc/passwd`.

**Observed result:** The web application displayed entries from `/etc/passwd`, including the `root`, `daemon`, and `bin` accounts.

**Status:** Successful.

## Test 2: Identify the Execution Context

**Objective:** Identify the operating-system user running the command and attempt to display `/etc/passwd`.

**Input:** Base64-encoded serialized data representing `id; cat /etc/passwd`.

**Expected result:** The command output should include execution-context information followed by the file contents, if the application accepts and executes the input as expected.

**Status:** Not verified. Record the actual result after testing.

## Security Note

These tests were performed against the intentionally vulnerable local training application. The results demonstrate the risks of passing untrusted data into a deserialization and command-execution pipeline.
