import pickle
import base64

command = "cat /etc/passwd"

serialized = pickle.dumps(command)
payload = base64.urlsafe_b64encode(serialized).decode()

print(payload)
