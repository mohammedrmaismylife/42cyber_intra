# Fixing the Vulnerability

## 1. Avoid Unsafe Deserialization

Do not use `pickle.loads()` on data supplied by users or other untrusted sources.

Use a safer data format, such as JSON, when the application only needs to exchange basic data structures.




