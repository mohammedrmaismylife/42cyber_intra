# Deserialization RCE Challenge

## Objective

The objective of this exercise was to identify and exploit an insecure deserialization vulnerability in a Flask application to display the contents of `/etc/passwd`.

## Vulnerability

The application decodes user-supplied Base64 data and deserializes it using Python's `pickle.loads()` function.

Deserializing untrusted data with `pickle` is unsafe because specially crafted serialized objects can execute Python code during deserialization.

The application also passes the resulting value to a function that executes operating-system commands, increasing the impact of the vulnerability.

## Exploitation

1. Started the vulnerable Flask application.
2. Opened the application in a web browser.
3. Submitted serialized data through the input form.
4. Observed the output displayed by the application.
5. Confirmed that the response contained entries from `/etc/passwd`.

## Result

The application successfully displayed the contents of `/etc/passwd`.

This demonstrates that user-controlled input can reach a sensitive file-reading operation through the vulnerable processing flow.

## Impact

Depending on the application's privileges and implementation, this vulnerability may allow unauthorized command execution, sensitive information disclosure, and further compromise of the application environment.

## Conclusion

The application should not deserialize untrusted data using `pickle`. Operating-system command execution should also be avoided where possible.
