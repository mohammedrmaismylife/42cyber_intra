# Ex02 — CBC IV Manipulation / Cryptographic Integrity

## Scope and important finding
This report is based on the supplied `cyber2x2.1.01.tgz` source code and the assignment PDF.
The application uses `AES-128-CBC` in `src/index.php`. In `get_identity()`, it encrypts the
known value in `config.php` (`$defaultId = 'guest'`) and stores the ciphertext in the PHP
session. The IV is also sent to the browser in the `token` cookie. Later, `test_identity()`
decrypts the session ciphertext using the IV supplied by that cookie and sets
`$_SESSION['isadmin']` when the resulting plaintext equals `admin`.

CBC mode is malleable when ciphertext is not authenticated. Because the IV is controllable
through the `token` cookie, changing the IV predictably changes the first plaintext block.
For a session created for `guest`, the IV can be modified so that the decrypted identity
becomes `admin`. This is a CBC IV bit-flipping attack (a cryptographic integrity failure).

## Reproduction conditions
1. Run the supplied application in its intended local Docker lab.
2. Obtain a legitimate application session so that the server has `$_SESSION['id']`
   containing the encrypted `guest` identity and the browser has the `token` cookie.
3. Use `cbc_iv_flip.py` to calculate a replacement `token` cookie value.
4. Replace only the `token` cookie in the same browser session, then reload the page.
5. If the session is still valid and the encrypted identity is `guest`, the application
   should treat the identity as `admin` and display the configured flag.

The script only calculates the replacement IV. It does not steal sessions, discover
credentials, or contact a remote host.

## Formula
CBC decryption of the first block is:

`P1 = D_K(C1) XOR IV`

To change known plaintext `P` into target plaintext `P'`, use:

`IV' = IV XOR P XOR P'`

Both values are padded to the AES block size (16 bytes). Here the known identity is
`guest` and the target identity is `admin`; PKCS#7 padding is identical after byte 5.

## Why this is not a demonstrated Padding Oracle
The assignment cover describes Padding Oracle, but the supplied PHP source does not expose
a distinguishable padding-valid/padding-invalid response in the login flow: both outcomes
lead to the same `login failed` page, and PHP errors are suppressed. Also, the supplied
archive contains no `db.sql` seed file or user rows. Therefore a reproducible classic
padding-oracle password-recovery attack cannot honestly be claimed from these supplied
files alone.

The concrete, source-verifiable issue is unauthenticated CBC IV manipulation in the
session identity check. Confirm whether your training platform has an additional database
seed or a revised source package before claiming the classic Padding Oracle portion.

## Other security observations
- `SECRET_KEY` is hard-coded in source.
- `rand()` is used to generate the IV instead of a cryptographically secure random source.
- `token` is trusted from the client without integrity verification.
- The username is interpolated into an SQL query. This is SQL injection risk, although
  SQL injection is explicitly out of scope for this exercise and is not used here.

## Files
- `Payloads.md`: safe lab inputs and the IV transformation formula.
- `Fix.md`: recommended defensive changes.
- `cbc_iv_flip.py`: local calculator for the modified IV.
