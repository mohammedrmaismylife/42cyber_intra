# Payloads and Test Inputs

This file records the inputs relevant to the source-code-confirmed CBC IV manipulation.

## Known and target identity
- Known plaintext: `guest`
- Target plaintext: `admin`
- AES block size: `16` bytes
- Padding: PKCS#7
- Cookie to transform: `token` (Base64-encoded IV)

## Transformation
The calculator pads both strings to 16 bytes and computes:

`modified_iv = original_iv XOR padded("guest") XOR padded("admin")`

Run:

```bash
python3 cbc_iv_flip.py --token '<current-token-cookie>'
```

The program prints a replacement Base64 `token` value. In the local lab only, replace
the existing `token` cookie with that value while preserving the same PHP session cookie.

## Expected observation
After refreshing the same valid session, the application may display the admin-only
flag if the session's encrypted identity is the ciphertext of `guest` and the server
accepts the modified IV.

## Negative / control checks
- Keep the original `token`: the identity remains `guest`.
- Change an unrelated cookie: it should not change the decrypted identity.
- Use the modified token with a different or expired PHP session: the expected result
  is not guaranteed because the ciphertext is stored server-side in that session.

## Padding Oracle assessment
The supplied source does not provide two distinguishable responses for valid versus
invalid PKCS#7 padding. Do not report a successful padding-oracle payload based solely
on this package. A classic padding-oracle test needs a reachable decryption endpoint and
a reliably distinguishable response or timing signal for padding validity.
