USE mine;
INSERT INTO users (username, encrypted_pass) VALUES ('testuser', 'VC/8F0mSIupuFZS2sy2S5JE7Z9lkA2UIpFisqrp14i4=');
