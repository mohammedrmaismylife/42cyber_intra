# Fix — Prevent CBC IV Manipulation and Padding Oracle Issues

## 1. Prefer authenticated encryption
Use an AEAD mode such as AES-256-GCM or ChaCha20-Poly1305. Store and verify the
authentication tag before using decrypted data. Never make authorization decisions from
unauthenticated CBC plaintext.

## 2. If CBC must be retained
- Generate the IV with a cryptographically secure random generator.
- Authenticate the IV and ciphertext together with HMAC (Encrypt-then-MAC).
- Verify the MAC in constant time before decryption.
- Reject modified messages before parsing or acting on plaintext.

## 3. Do not trust authorization state from a client-controlled value
Keep the authenticated user identity and role on the server side. Do not let a client
cookie supply an IV that can alter an authorization-bearing plaintext. Use a server-side
session identifier and regenerate the session after authentication.

## 4. Key management
Remove `SECRET_KEY` from source code. Load keys from a secret manager or protected
environment configuration, rotate exposed keys, and restrict access.

## 5. Error handling
Return the same externally observable response for all decryption failures. Avoid
revealing padding errors, decryption errors, stack traces, or different timing behavior.
Log details securely on the server only.

## 6. SQL query protection (separate issue)
Use parameterized queries / prepared statements for the username lookup. Do not build
SQL by concatenating user input. This is a separate code weakness; SQL injection is not
used as the exploit for this exercise.

## Example design
- On login, validate credentials.
- Store `user_id` and role in the server-side session.
- Give the browser only a random, unpredictable session identifier marked Secure,
  HttpOnly, and SameSite.
- On each request, load the identity from the server-side session.
- If encrypted data must be transported, use authenticated encryption and verify its tag.

## Verification checklist
- Altering any cookie byte cannot change a user's role.
- Tampered ciphertext or IV is rejected.
- Invalid authentication tags produce a generic failure.
- No padding-validity oracle is observable.
- Keys are not embedded in source control.
- SQL parameters are bound, not concatenated.
