#!/usr/bin/env python3
"""Calculate a CBC IV bit-flip for the supplied local training application.

This is a calculator only: it does not make HTTP requests or access a server.
Use only in the intentionally provided local lab and only with your own session.
"""
import argparse
import base64
import sys

BLOCK = 16

def pkcs7(data: bytes) -> bytes:
    n = BLOCK - (len(data) % BLOCK)
    return data + bytes([n]) * n

def main():
    parser = argparse.ArgumentParser(description="Calculate a replacement Base64 token IV")
    parser.add_argument("--token", required=True, help="Current Base64 token cookie from your own lab session")
    parser.add_argument("--known", default="guest", help="Known session identity (default: guest)")
    parser.add_argument("--target", default="admin", help="Target identity (default: admin)")
    args = parser.parse_args()

    try:
        iv = base64.b64decode(args.token, validate=True)
    except Exception:
        parser.error("token must be valid Base64")
    if len(iv) != BLOCK:
        parser.error("decoded token must be exactly 16 bytes (AES IV)")

    known = pkcs7(args.known.encode())
    target = pkcs7(args.target.encode())
    if len(known) != BLOCK or len(target) != BLOCK:
        parser.error("known and target must fit in one AES block")

    changed = bytes(iv[i] ^ known[i] ^ target[i] for i in range(BLOCK))
    print(base64.b64encode(changed).decode())

if __name__ == "__main__":
    main()
