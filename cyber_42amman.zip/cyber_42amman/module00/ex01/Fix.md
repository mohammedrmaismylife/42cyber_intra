# Fix — Mitigating CSRF

The root cause of this vulnerability is that the server trusts a
request purely because a valid session cookie is attached, without
verifying that the request was intentionally initiated by the user
through the application itself. The fixes below address that gap from
several angles — in practice, applying more than one layer together
is best practice (defense in depth).

## 1. CSRF Tokens (primary defense)

Generate a unique, unpredictable, per-session (or per-request) token
on the server. Embed it as a hidden field in every state-changing
form, and require the server to validate that token before processing
the request. Reject the request if the token is missing, invalid, or
doesn't match the one tied to the user's session.

```html
<form action="/transfer" method="POST">
  <input type="hidden" name="csrf_token" value="SERVER_GENERATED_RANDOM_TOKEN">
  <input type="number" name="amount">
  <input type="submit" value="Transfer Money">
</form>
```

An attacker hosting a page on a different origin has no way to read
or predict this token, so their forged form submission will be
rejected.

## 2. SameSite Cookies

Set the `SameSite` attribute on session cookies to `Strict` or `Lax`.
This tells the browser not to send the cookie on cross-site requests
originating from a different domain, which directly breaks the
mechanism CSRF relies on.

```
Set-Cookie: session=abc123; SameSite=Strict; Secure; HttpOnly
```

- `Strict`: the cookie is never sent on cross-site requests (most
  secure, but can affect some legitimate cross-site navigation flows).
- `Lax`: the cookie is sent on top-level navigations (e.g. clicking a
  link) but not on cross-site POST requests or background requests —
  a good practical default for most applications.

## 3. Verify Origin / Referer headers

On the server, check that the `Origin` (or fallback `Referer`) header
of incoming state-changing requests matches the application's own
domain. Reject the request otherwise.

```
if request.headers["Origin"] != "https://trusted-app-domain.com":
    reject_request()
```

This is a useful secondary check, especially as a defense-in-depth
measure alongside CSRF tokens, though it should not be relied upon as
the sole protection since header handling can vary across proxies and
older browsers.

## 4. Require re-authentication for sensitive actions

For highly sensitive operations such as transferring funds or
changing account credentials, require the user to re-enter their
password (or complete a second factor) immediately before the action
is executed. This limits the impact even if a CSRF request somehow
gets through.

## 5. Prefer POST over GET for state-changing actions

State-changing actions should never be exposed via `GET` requests,
since `GET` requests can be triggered trivially (e.g. via an `<img>`
or `<link>` tag) and are commonly cached, logged, and prefetched by
browsers and proxies — all of which increase CSRF exposure. `POST`
(combined with the protections above) is the appropriate choice here.

## Summary

| Defense | Protects against |
|---|---|
| CSRF token | Forged requests from any external origin |
| SameSite cookie | Cookie being sent on cross-site requests at all |
| Origin/Referer check | Requests not originating from the app itself |
| Re-authentication | Impact of a successful forged request |
| POST over GET | Trivial one-line (`<img>`) exploitation |

Applying CSRF tokens together with `SameSite` cookies is generally
considered sufficient and is the current OWASP-recommended baseline
for protecting state-changing endpoints like `/transfer`.
