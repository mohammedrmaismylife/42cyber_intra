# Vulnerability: CSRF (Cross-Site Request Forgery)

## Type

**CSRF — Cross-Site Request Forgery**, listed under the OWASP Top 10
(historically A8:2013/A5:2017, now folded into **A01:2021 — Broken
Access Control**).

## What is CSRF?

CSRF is a vulnerability that allows an attacker to trick a victim's
browser into sending an unwanted, authenticated request to a web
application the victim is currently logged into — without the
victim's knowledge or consent.

It works because of two combined behaviors:

1. **The browser automatically attaches cookies** (including session
   cookies) to every request sent to a given domain, regardless of
   which page or origin triggered that request.
2. **The server trusts the request solely because a valid session
   cookie is present**, without verifying that the request was
   intentionally initiated by the user from the application's own
   interface.

As a result, if a victim is authenticated on a vulnerable site and is
lured into visiting an attacker-controlled page (via a link, email,
ad, or embedded content), that page can silently submit a form or
request to the vulnerable site. The browser includes the victim's
session cookie automatically, and the server processes the action as
if the legitimate user had performed it themselves.

## Where the vulnerability lives in this application

The `/transfer` endpoint accepts a `POST` request with an `amount`
parameter and immediately processes a money transfer. The endpoint
does **not**:

- Include or verify any **CSRF token** tied to the user's session.
- Check the request's **Origin** or **Referer** header.
- Require any form of **re-authentication** (e.g. re-entering a
  password) before executing a sensitive, state-changing action.

Because none of these protections exist, any page — hosted anywhere,
including a plain local HTML file — can trigger a transfer on behalf
of a logged-in victim simply by auto-submitting a form that targets
`/transfer`.

## Why this matters

CSRF is dangerous specifically because it does not require the
attacker to steal credentials, bypass authentication, or read any
data from the victim. It only requires:

1. The victim to have an active session on the vulnerable site.
2. The victim's browser to visit a page controlled by the attacker.

This makes it a silent, low-effort attack vector for any
state-changing action (transferring money, changing account details,
deleting data, etc.) that is not properly protected.

## Sources

- OWASP CSRF Prevention Cheat Sheet:
  https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html
- OWASP Top 10 — A01:2021 Broken Access Control:
  https://owasp.org/Top10/A01_2021-Broken_Access_Control/
