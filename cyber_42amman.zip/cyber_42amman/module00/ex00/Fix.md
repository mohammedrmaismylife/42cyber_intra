# Fixing the XSS Vulnerability

## 1. Do not insert untrusted input with `innerHTML`

Current unsafe pattern:

```javascript
document.getElementById("output").innerHTML = "<b>" + userInput + "</b>";
```

If the application only needs to display the input as text, use a text API:

```javascript
document.getElementById("output").textContent = userInput;
```

If bold formatting is required, create the `<b>` element with DOM APIs and assign the user value through `textContent`, rather than concatenating it into an HTML string.

## 2. Never execute user input as JavaScript

Remove this unsafe pattern:

```javascript
var script = document.createElement("script");
script.textContent = userInput;
document.body.appendChild(script);
```

User-supplied text must not be treated as executable JavaScript. If the application needs a specific action, implement an explicit, validated operation instead of executing arbitrary input.

## 3. Protect session cookies

Set sensitive session cookies with appropriate attributes, especially:

- `HttpOnly` to prevent JavaScript from reading the cookie.
- `Secure` when served over HTTPS.
- `SameSite` with a suitable value to reduce some cross-site request risks.

The cookie in the training example is created with JavaScript, so JavaScript cannot set its `HttpOnly` attribute. In a real application, sensitive session cookies should be set by the server using the `Set-Cookie` response header.

`HttpOnly` reduces the risk of cookie theft but does not remove XSS or prevent all actions injected scripts might perform.

## 4. Add defense in depth

- Apply context-appropriate output encoding when rendering untrusted data.
- Validate inputs according to business requirements; validation alone is not a substitute for safe output handling.
- Deploy a suitable Content Security Policy (CSP), preferably avoiding unsafe inline scripts.
- Test all code paths that render or process user-controlled data.

## 5. Verify the fix

1. Replace unsafe rendering with safe DOM APIs.
2. Remove dynamic execution of user input.
3. Retest with plain text and the XSS test payload.
4. Confirm that the payload is displayed as text and does not execute.
5. Verify that sensitive cookies are set by the server with the appropriate attributes.

## Conclusion

The main fixes are to render untrusted input as text, never execute user input as code, and protect sensitive cookies with server-set security attributes.
