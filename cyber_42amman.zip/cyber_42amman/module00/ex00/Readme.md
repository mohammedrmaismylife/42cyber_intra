# Exercise 00 — Cross-Site Scripting (XSS)

## Objective

The objective of this exercise is to identify and demonstrate the XSS vulnerability in the provided local web application, and to document its impact and remediation.

## Application behavior

The application accepts text from the user and passes it to `displayText()`.

The supplied `index.html` contains these relevant statements:

```javascript
document.getElementById("output").innerHTML = "<b>" + userInput + "</b>";

var script = document.createElement("script");
script.textContent = userInput;
document.body.appendChild(script);
```

The first statement inserts user-controlled data into the page as HTML. The second creates a script element using user-controlled data. Both patterns are unsafe for untrusted input.

The page also creates a cookie:

```javascript
document.cookie = "ftCookies=If_You_See_Me_Its_Win";
```

The cookie can be read by JavaScript in this demonstration because it is not marked `HttpOnly`.

## Vulnerability

**Type:** Cross-Site Scripting (XSS) risk caused by unsafe handling of user input.

The application inserts input into `innerHTML` and also treats input as JavaScript source by assigning it to a newly created script element. This can allow input to be interpreted as active content rather than plain text.

## Impact

Depending on the browser context and the data available to scripts, XSS can allow an attacker to modify page content, display misleading content, or access information exposed to JavaScript. Cookies marked `HttpOnly` cannot be read through `document.cookie`; however, `HttpOnly` does not fix the underlying XSS vulnerability.

## Testing

1. Start the supplied application using `./start.sh`.
2. Open the local URL printed by the script.
3. Enter a harmless test string and submit it to observe where the value appears.
4. In this authorized local lab, test whether HTML/event-handler input is interpreted by the page.
5. Inspect `document.cookie` in the browser console to verify which cookies are readable by JavaScript.
6. Record the exact payloads and observed outcomes in `Payloads.md`.

Only report results that were actually observed in the browser.

## Example exploitation scenarios

1. **Page manipulation:** an attacker could cause untrusted markup or script to alter what a user sees on the page.
2. **Access to script-readable data:** if a cookie or other sensitive value is accessible to JavaScript, injected code may be able to read it. `HttpOnly` reduces cookie-reading risk but does not prevent other XSS effects.

## Conclusion

The application should not insert untrusted data as HTML or execute it as JavaScript. See `Fix.md` for remediation recommendations.
